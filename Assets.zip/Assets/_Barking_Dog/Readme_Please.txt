Hi :)

Here is a small modular kit! Free for commercial or freeware games/apps.
The package is given for free, do not contact me for modifications or special works...

														Barking Dog
														
																	

PS : And do not forget to write a review/stars on the Unity Store :)

---------------------------------------------------------------------------------

If you like this kind of product, take a look on my line up, on the Unity Store : 


Store : http://u3d.as/sUN

Facebook : https://www.facebook.com/pg/BigBarkingDog

Twiter : https://twitter.com/bad_barking_dog



You will find many modular kits, with various stylish :)

---------------------------------------------------------------------------------